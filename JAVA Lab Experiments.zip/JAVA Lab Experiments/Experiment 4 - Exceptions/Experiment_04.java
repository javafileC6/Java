//Make a program to make use of all 5 exceptions keywords that is try, catch, finally, throw and throws.
import java.lang.*;

public class Experiment_04{

    static void divide(int a, int b) throws ArithmeticException{
        if(b == 0){
            throw new ArithmeticException("Divide by zero error! ");
        }
        else{
            System.out.println("Result: " + a/b);
        }
    }

    public static void main(String[] args){


        //Try and Catch and Finally Keywords -----
        try{
            int a = 10;
            int b = 0;
            int c = a/b;
            System.out.println(c);

        }catch(ArithmeticException e){

            System.out.println(e);

        }finally{

            System.out.println("\nFinally Block Always Executed!\n");
        }


        //Throw Keyword --------------
        int num = -5;
        if (num < 1) {  
            throw new ArithmeticException("\nNumber is negative, cannot calculate square root! \n");  
        }  
        else {  
            System.out.println("\nSquare root of " + num + " is: " + Math.sqrt(num));   
        }  

        //Throws Keyword----------------
        int n = 10;
        int m = 0;

        divide(n,m);
    }
}



