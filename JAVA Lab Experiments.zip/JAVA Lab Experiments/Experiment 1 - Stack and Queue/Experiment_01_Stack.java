import java.util.*;

public class Experiment_01_Stack {

    //Stack Class 
    public static class Stack {

        static final int MAX = 10;
        int top = -1;
        int st[] = new int[MAX];

        boolean isEmpty(){
            if(top==-1) return true;
            else return false;
        }

        int size(){
            return top+1;
        }

        int top(){
            if(top==-1){
                System.out.println("Stack is Empty!");
                return 0;
            }
            else{
                return st[top];
            }
        }

        void push(int n){

            if(top>=MAX-1){
                System.out.println("Stack Overflow!");
            }
            else{
                top++;
                st[top] = n;
            }
        }

        void pop(){
            if(top==-1){
                System.out.println("Stack Underflow!");
            }
            else{
                System.out.println(st[top--] + " Popped!");
            }
        }

        void display(){
            if(top==-1){
                System.out.println("Stack is Empty!");
            }
            else{
                System.out.println("Stack is : ");
                for(int i=top;i>=0;i--){
                    System.out.println(st[i]);
                }
            }
        }

    }
    
    public static void main(String[] args){

        System.out.println("\n***** Stack Implementation *****\n");

        System.out.println("Enter your choice from (1 - 7): ");
        System.out.println("1. Push");
        System.out.println("2. Pop");
        System.out.println("3. Top");
        System.out.println("4. Display");
        System.out.println("5. isEmpty");
        System.out.println("6. Size");
        System.out.println("7. Exit");

        Scanner sc = new Scanner(System.in);
        Stack s = new Stack();
        int option = 0;

        while(option!=7){
            
            System.out.print("\nEnter your choice: ");
            option = sc.nextInt();
        
            switch(option){
                case 1:
                    System.out.print("Enter the number to be pushed: ");
                    int n = sc.nextInt();
                    s.push(n);
                    break;

                case 2:
                    s.pop();
                    break;

                case 3:
                    System.out.println("Top element is: "+s.top());
                    break;

                case 4:
                    s.display();
                    break;

                case 5:
                    System.out.println("isEmpty: "+s.isEmpty());
                    break;

                case 6:
                    System.out.println("Size: "+s.size());
                    break;

                case 7:
                    System.out.println("Exited!");
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }
        }

        sc.close();

    }
}
