import java.util.*;

public class Experiment_01_Queue {
    
    public static class Queue{

        static final int MAX = 10;
        int front = -1;
        int rear = -1;
        int q[] = new int[MAX];


        boolean isEmpty(){
            if(front==-1 && rear==-1) return true;
            else return false;
        }

        int size(){
            return rear-front+1;
        }

        int front(){
            if(front==-1){
                System.out.println("Queue is Empty!");
                return 0;
            }
            else{
                return q[front];
            }
        }

        int rear(){
            if(rear==-1){
                System.out.println("Queue is Empty!");
                return 0;
            }
            else{
                return q[rear];
            }
        }

        void enqueue(int n){

            if(rear>=MAX-1){
                System.out.println("Queue Overflow!");
            }
            else{
                if(front==-1) front++;
                rear++;
                q[rear] = n;
            }
        }

        void dequeue(){
            if(front==-1){
                System.out.println("Queue Underflow!");
            }
            else{
                System.out.println(q[front++] + " Dequeued!");
                if(front>rear){
                    front = -1;
                    rear = -1;
                }
            }
        }

        void display(){
            if(front==-1){
                System.out.println("Queue is Empty!");
            }
            else{
                for(int i=front;i<=rear;i++){
                    System.out.print(q[i] + " ");
                }
                System.out.println();
            }
        }


    }

    public static void main(String[] args){

        System.out.println("\n***** Queue Implementation *****\n");

        System.out.println("Enter your choice from (1 - 7): ");
        System.out.println("1. Enqueue: ");
        System.out.println("2. Dequeue: ");
        System.out.println("3. Front: ");
        System.out.println("4. Rear: ");
        System.out.println("5. Display");
        System.out.println("6. isEmpty");
        System.out.println("7. Size");
        System.out.println("8. Exit");

        Queue q = new Queue();
        Scanner sc = new Scanner(System.in);
        int option = 0;

        while(option!=8){
                
            System.out.print("\nEnter your choice: ");
            option = sc.nextInt();

            switch(option){
                case 1:
                    System.out.print("Enter the element to be enqueued: ");
                    int n = sc.nextInt();
                    q.enqueue(n);
                    break;

                case 2:
                    q.dequeue();
                    break;

                case 3:
                    System.out.println("Front: " + q.front());
                    break;

                case 4: 
                    System.out.println("Rear: " + q.rear());
                    break;

                case 5:
                    q.display();
                    break;

                case 6:
                    System.out.println("isEmpty: " + q.isEmpty());
                    break;

                case 7:
                    System.out.println("Size: " + q.size());
                    break;

                case 8:
                    System.out.println("Exited!");
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }
        }

        sc.close();
        
    }
}
