import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Visit extends HttpServlet{

    static int i = 0; 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<title>WebsiteVisitCount</title>");
        String name= "Rahul Kumar";
        Cookie c = new Cookie("visit",String.valueOf(i));
        response.addCookie(c);
            
        int j = Integer.parseInt(c.getValue());     
        if(j == 0){
           out.println("Welcome " + name);
        }
        else{
            out.println(name + " you have Visited this website " + j + " times");
        }
        i++;
    }
}
