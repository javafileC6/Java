import java.beans.*;

public class BoundBeans {
    private String name;
    private int age;

    private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    private VetoableChangeSupport vcs = new VetoableChangeSupport(this);

    public BoundBeans() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) throws PropertyVetoException {
        String oldName = this.name;
        vcs.fireVetoableChange("Name", oldName, name);
        this.name = name;
        pcs.firePropertyChange("Name", oldName, name);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) throws PropertyVetoException {
        int oldAge = this.age;
        vcs.fireVetoableChange("Age", oldAge, age);
        this.age = age;
        pcs.firePropertyChange("Age", oldAge, age);
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        pcs.removePropertyChangeListener(listener);
    }

    public void addVetoableChangeListener(VetoableChangeListener listener) {
        vcs.addVetoableChangeListener(listener);
    }

    public void removeVetoableChangeListener(VetoableChangeListener listener) {
        vcs.removeVetoableChangeListener(listener);
    }

    public static void main(String[] args) throws PropertyVetoException {
        BoundBeans bean = new BoundBeans();
        bean.addVetoableChangeListener(new VetoableChangeListener() {
            @Override
            public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
                if (evt.getNewValue().equals("Invalid name")) {
                    throw new PropertyVetoException("Invalid name", evt);
                }
            }
        });
        bean.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("\n" + evt.getPropertyName() + " Changed From " + evt.getOldValue() + " To " + evt.getNewValue());
            }
        });
        bean.setName("Niket Chugh");
        bean.setAge(20);
        try {
            bean.setName("Invalid Name \n");
        } catch (PropertyVetoException e) {
            System.out.println(e.getMessage());
        }
    }
}
