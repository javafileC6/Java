//WAP to convert content of file.txt to Uppercase letters and save in same file.
import java.util.*;
import java.io.*;

public class Experiment_05{

    public static void main(String[] args) {
        
        try{
            File file = new File("file.txt");
            Scanner sc = new Scanner(file);
            String str = "";

            while(sc.hasNextLine()){
                str += sc.nextLine();
                str += '\n';
            }

            System.out.println("\nFile Before Converting: \n\n" + str);

            str = str.toUpperCase();

            System.out.println("\nFile After Converting: \n\n" + str);

            FileWriter fw = new FileWriter(file);
            fw.write(str);
            fw.close();
            sc.close();

        }catch(FileNotFoundException e){

            System.out.println("File not found");
        }

        catch(IOException e){

            System.out.println("Error");
        }
    }
}







//Extras------------------------------------------

//Program to Read file.txt and Display the content. 

// try{
//     File file = new File("file.txt");
//     Scanner sc = new Scanner(file);
//     while(sc.hasNextLine()){
//         String line = sc.nextLine();
//         System.out.println(line.toUpperCase());
//     }
//     sc.close();
// }catch(FileNotFoundException e){
//     System.out.println("File not found");
// }