//Java program to show dynamic polymorphism in Java.
import java.lang.*;

class Animal{
    void eat(){
        System.out.println("Animal eating...! \n");
    }
}

class Dog extends Animal{
    void eat(){
        System.out.println("Dog eating Bread...! \n");
    }
}

class Cat extends Animal{
    void eat(){
        System.out.println("Cat eating Rat...! \n");
    }
}

class Lion extends Animal{
    void eat(){
        System.out.println("Lion eating Meat...! \n");
    }
}

public class Experiment_02_Polymorphism{

    public static void main(String[] args){

        System.out.println("Demonstrating Concept of Polymorphism in Java!\n");

        Animal a = new Animal();
        Animal b = new Dog();
        Animal c = new Cat();
        Animal d = new Lion();

        a.eat();
        b.eat();
        c.eat();
        d.eat();
    }

}
