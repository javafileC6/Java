// Java Program to Demonstrate Concept of interfaces
import java.lang.*;

// Interface
interface Animal{
    void sound();
}

// Class Dog
class Dog implements Animal{
    public void sound(){
        System.out.println("Dog: Bark...!\n");
    }
}

// Class Cat
class Cat implements Animal{
    public void sound(){
        System.out.println("Cat: Meow...!\n");
    }
}

// Class Lion
class Lion implements Animal{
    public void sound(){
        System.out.println("Lion: Roar...!\n");
    }
}

// Main Class
public class Experiment_02_Interfaces{

    public static void main(String[] args){

        System.out.println("Demonstrating Concept of Interfaces in Java!\n");

        Animal a = new Dog();
        Animal b = new Cat();
        Animal c = new Lion();

        a.sound();
        b.sound();
        c.sound();
    }

}